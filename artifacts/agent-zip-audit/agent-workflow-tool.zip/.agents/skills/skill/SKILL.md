---
name: skill
description: 작업 지침·Skill — AGENTS.md에 지정된 단계에서 사용하는 작업 지침입니다.
---

요청을 검토 도구로 한 번 전달한 뒤 결과를 정리하세요.
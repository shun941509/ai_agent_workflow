---
name: wf-edit-05f1cee04b92
description: Workflow에서 편집 역할에 위임한 작업을 수행합니다.
---

작업을 시작할 때 프로젝트 루트(AGENTS.md가 있는 폴더)를 기준으로 `agents/wf-edit-05f1cee04b92.md` 파일을 먼저 여세요. 이 역할 지침을 위임받은 입력에 적용하고 지정된 결과를 호출자에게 반환하세요.

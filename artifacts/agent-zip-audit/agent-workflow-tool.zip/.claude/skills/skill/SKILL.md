---
name: skill
description: 작업 지침·Skill — AGENTS.md에 지정된 단계에서 사용하는 작업 지침입니다.
---

프로젝트 루트 기준 `.agents/skills/skill/SKILL.md`를 열고 현재 요청에 그 지침을 적용하세요. 원본 지침의 상대경로는 원본 SKILL.md가 있는 폴더를 기준으로 읽으세요.

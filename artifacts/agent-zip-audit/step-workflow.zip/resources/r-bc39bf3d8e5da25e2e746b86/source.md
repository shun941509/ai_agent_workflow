// src/todos.ts
type Todo = { title: string; completed: boolean };

export function visibleTodos(todos: Todo[], hideCompleted: boolean): Todo[] {
  return hideCompleted ? todos.filter(todo => todo.completed) : todos;
}